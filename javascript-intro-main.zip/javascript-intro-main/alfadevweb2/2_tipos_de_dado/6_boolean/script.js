console.log(true);
console.log(false);

console.log(10 > 2);
console.log(5 > 10);


console.log(typeof true);
console.log(typeof false);
console.log(typeof(10 > 2));
console.log(typeof(5 > 10));