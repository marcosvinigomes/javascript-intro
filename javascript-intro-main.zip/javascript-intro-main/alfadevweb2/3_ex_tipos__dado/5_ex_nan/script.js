console.log(9 * 'z');
console.log(typeof(9 * 'z'));


