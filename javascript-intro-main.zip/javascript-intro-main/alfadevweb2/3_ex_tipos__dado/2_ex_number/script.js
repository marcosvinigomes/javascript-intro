console.log(200);
console.log(99.90);
console.log(typeof(99.99));

