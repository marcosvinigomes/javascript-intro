console.log(5 > 3);
console.log(typeof(5 > 3));

console.log(5!= 4);



