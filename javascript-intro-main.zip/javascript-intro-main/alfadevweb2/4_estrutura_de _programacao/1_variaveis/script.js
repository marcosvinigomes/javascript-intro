console.log(9 * 'z');
console.log(typeof(9 * 'z'));

nome = "Marcos";
console.log(nome);

console.log(`O meu nome é ${Marcos}`);
console.log("O meu nome é $(Marcos)");
console.log(' O meu nome é $(Marcos)');

let laranjas = 5;

console.log(laranjas * laranjas);

let cerveja = 2;
var refrigerante = 3;
const agua = 4 ;

console.log(cerveja)