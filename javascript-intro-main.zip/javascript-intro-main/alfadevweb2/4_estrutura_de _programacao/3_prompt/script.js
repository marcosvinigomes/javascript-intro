idade = prompt("qual sua idade truta ? ");
console.log("sua idade e " + idade);

nome = prompt("qual seu nome?");
console.log('olá '+ nome + ' sua idade é ' + idade );

