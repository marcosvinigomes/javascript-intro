console.log(5>2 ? 'é sim' : 'é não');
console.log(2>2 ? 'é sim' : 'é não');