console.log("Hi my name is Not3du :)");
console.log('Sou estudante');
console.log(`isto é um teste`);


console.log(typeof("Hi my name is Not3du :)"));
console.log(typeof('Sou estudante'));
console.log(typeof(`isto é um teste`)); 