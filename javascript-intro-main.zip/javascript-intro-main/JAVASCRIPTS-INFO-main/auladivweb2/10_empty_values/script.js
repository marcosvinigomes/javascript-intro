console.log(undefined);
console.log(null);

x='';

console.log(x);

console.log(5 * null);
