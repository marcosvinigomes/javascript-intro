console.log(2 + 2);
console.log(2 - 7);
console.log(5 * 3);
console.log(10 / 100);

console.log(21 % 2);
console.log(20 % 2);

console.log(typeof (2 + 3));

console.log(typeof(5 - 3));