//declarando funçao

let y = 10;

function num(){
    if(5>2){
         let y = 100;
        console.log();
    }
   
} 
num();
console.log(y);