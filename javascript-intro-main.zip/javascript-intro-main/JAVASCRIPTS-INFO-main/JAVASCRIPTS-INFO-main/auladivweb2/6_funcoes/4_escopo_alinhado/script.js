//declarando funçao


let a  = 5;
function mult (x,y){
    let a = x * y;
    if(a>10){
        let a = 0;
        console.log(a);
    }
    console.log(a);
}

mult(3,7);
console.log(a);