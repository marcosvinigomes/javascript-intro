//declarando funçao

function imprimirConsole (){
    // o que faz a função
    console.log("olá mundo")
    
}
//chamando 
imprimirConsole();
                       //(num)= parametro
function imprimirNumero(num){
    console.log("o numero é: " + num);
}
imprimirNumero(2);
imprimirNumero(25);
imprimirNumero(202);