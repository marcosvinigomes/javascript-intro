
escrever = () =>{
    console.log("olá mundo estou sendo ameaçado");
}
escrever();
soma = (a,b) =>{
    return a + b;
}
console.log(soma(10,20));
x = soma (10,10);
y = soma (20,10);
console.log(x + y );