
nome = "Marcos"

switch(nome);
case "daniel";
console.log("Bem vindo Marcos")
