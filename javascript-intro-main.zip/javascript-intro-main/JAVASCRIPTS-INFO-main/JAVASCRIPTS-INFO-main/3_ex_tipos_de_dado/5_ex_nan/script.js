console.log(9 * 'a');
