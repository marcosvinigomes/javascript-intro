console.log(15 < 10 && 3 > 4);
console.log(25 > 9 || 85 > 45);
console.log(!(2 != 4 || 19 == 9));