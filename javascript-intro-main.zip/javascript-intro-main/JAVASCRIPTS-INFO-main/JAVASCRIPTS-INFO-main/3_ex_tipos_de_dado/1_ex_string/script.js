console.log("Aspas duplas")
console.log('aspas simples')
console.log(`Literels`)