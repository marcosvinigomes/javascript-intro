console.log(15 <= 10);
console.log(25 > 9);
console.log(2 != 4);