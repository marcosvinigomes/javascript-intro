x = 10;
while(x > 0){
    console.log('O valor de X é: ' + x);

    x--;

}

while(x <= 10){
    console.log('O valor de x é: ' + x);
    x++;
}
