idade = 39;

if(idade == 19){
    console.log('Você não pode beber');
}
if(idade >= 18){
    console.log('Você pode dirigir!');

}

usuario = "Allan";
senha = 'lala123';

if((usuario == "Allan") && (senha == "lala123")){
    console.log('Acesso liberado!');
    alert('Bem vindo ' + usuario + '!'); 
}
