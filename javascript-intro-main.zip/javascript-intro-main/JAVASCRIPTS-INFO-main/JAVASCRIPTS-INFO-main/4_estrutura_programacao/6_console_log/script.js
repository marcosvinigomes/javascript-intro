idade = 21;
nome = "Nome de vocês mesmo";

console.log(`meu nome é ${nome}, tenho ${idade} anos.`)
console.log('meu nome é ' + nome + ' tenho ' + idade + ' anos.')
