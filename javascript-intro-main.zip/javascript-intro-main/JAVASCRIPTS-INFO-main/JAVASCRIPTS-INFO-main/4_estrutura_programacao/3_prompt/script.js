idade = prompt('Qual sua idade dude ?')

console.log('Sua idade é ' + idade) ;

nome = prompt("Qual seu nome ?");

console.log("Olá " + nome + "sua idade é " + idade)