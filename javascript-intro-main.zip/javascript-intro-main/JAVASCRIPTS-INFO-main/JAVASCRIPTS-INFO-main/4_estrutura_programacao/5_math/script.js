maior = Math.max(110, 50, 90, 33, 45, 32, 92, 9912, 2323, 188);
console.log(maior);

menor = Math.min(232, 112, 2, 33, 11, 12, 42424, 1);
console.log(menor);

arredonda = Math.ceil(5.100);
console.log(arredonda);

aleatorio = Math.random(110, 50, 90, 33, 45, 32, 92, 9912, 2323, 188);
console.log(aleatorio);