let nome = 'Edu';
console.log(nome)

console.log(`O meu nome é ${nome}`);

let laranjas = 5;

console.log(laranjas * laranjas);

let cerveja = 2;
var refrigerante = 3;
const agua = 4;

// agua náo pode mudar o valor

console.log(refrigerante);
