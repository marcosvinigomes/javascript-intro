//3nome = 'Edu'
nome3 = 'edu';
$sobrenome = ' Montanhani '

_idade = 15;

//!nome = 'teste';

console.log(nome3 + $sobrenome + _idade);